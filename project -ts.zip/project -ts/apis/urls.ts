export const urls = {
    auth: {
      login: "/auth/login",
      signup: "/auth/signup",
    },
    user:"/user",
    sneaker: {
      new: "/sneaker",
      brands: "/sneaker/brands",
      item:"/sneaker/item"
    },
}